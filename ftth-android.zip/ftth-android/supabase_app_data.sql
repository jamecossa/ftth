-- Registo FTTH: tabela de dados por utilizador (versao com seguranca reforcada)
-- Cola isto em Supabase > SQL Editor > New query e clica em Run.
-- Pode ser executado mais de uma vez sem dar erro.

create table if not exists public.app_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  profile jsonb not null default '{}'::jsonb,
  services jsonb not null default '[]'::jsonb,
  records jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

-- Limites e tipos: impede dados malformados ou gigantes (abuso de armazenamento)
alter table public.app_data drop constraint if exists app_data_limites;
alter table public.app_data add constraint app_data_limites check (
  jsonb_typeof(profile) = 'object'
  and jsonb_typeof(services) = 'array'
  and jsonb_typeof(records) = 'array'
  and jsonb_array_length(services) <= 500
  and jsonb_array_length(records) <= 50000
  and pg_column_size(profile) < 200000
  and pg_column_size(services) < 500000
  and pg_column_size(records) < 8000000
);

-- Seguranca por linha: cada pessoa so ve e altera os seus proprios dados
alter table public.app_data enable row level security;

drop policy if exists "ver os proprios dados" on public.app_data;
drop policy if exists "criar os proprios dados" on public.app_data;
drop policy if exists "alterar os proprios dados" on public.app_data;
drop policy if exists "apagar os proprios dados" on public.app_data;

create policy "ver os proprios dados" on public.app_data
  for select to authenticated
  using (auth.uid() = user_id);

create policy "criar os proprios dados" on public.app_data
  for insert to authenticated
  with check (auth.uid() = user_id);

create policy "alterar os proprios dados" on public.app_data
  for update to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "apagar os proprios dados" on public.app_data
  for delete to authenticated
  using (auth.uid() = user_id);

-- Permissoes: so utilizadores com sessao iniciada; visitantes anonimos nao tem acesso nenhum
revoke all on public.app_data from anon;
revoke all on public.app_data from public;
grant select, insert, update, delete on public.app_data to authenticated;
